package no.isfjording.trening;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.os.Build;
import android.os.ParcelUuid;

import java.util.Collections;
import java.util.UUID;

/** Pulsbelte (HRM600 og andre belter med standard pulsmåler-tjeneste) over Bluetooth LE. */
@SuppressLint("MissingPermission")
public class Hr {
    static final UUID HRS = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    static final UUID HRM = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    static final UUID CCC = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    static BluetoothGatt gatt;
    static BluetoothDevice dev;
    static boolean connected, scanning, want;
    static BluetoothLeScanner scanner;

    static void state(String s) { Hub.js("window.__hrState&&__hrState('" + s + "')"); }

    static void connect(Context c) {
        BluetoothManager bm = (BluetoothManager) c.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter ad = bm == null ? null : bm.getAdapter();
        if (ad == null || !ad.isEnabled()) { state("btoff"); return; }
        if (connected) { state("connected"); return; }
        want = true;
        if (scanning) return;
        scanner = ad.getBluetoothLeScanner();
        if (scanner == null) { state("btoff"); return; }
        scanning = true;
        state("scanning");
        ScanFilter f = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(HRS)).build();
        ScanSettings st = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        try { scanner.startScan(Collections.singletonList(f), st, scanCb); } catch (Exception e) { scanning = false; state("noperm"); return; }
        Hub.main.postDelayed(() -> {
            if (scanning) { stopScan(); if (!connected && gatt == null) state("notfound"); }
        }, 15000);
    }

    static void stopScan() {
        scanning = false;
        try { if (scanner != null) scanner.stopScan(scanCb); } catch (Exception e) { }
    }

    static final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult r) {
            if (!scanning) return;
            stopScan();
            dev = r.getDevice();
            gatt = dev.connectGatt(Hub.app, false, cb, BluetoothDevice.TRANSPORT_LE);
        }
    };

    static void stopReconnect() { want = false; }

    static void handle(byte[] v) {
        if (v == null || v.length < 2) return;
        int flags = v[0] & 0xff;
        int hr = (flags & 1) != 0 && v.length >= 3 ? ((v[1] & 0xff) | ((v[2] & 0xff) << 8)) : (v[1] & 0xff);
        if (hr > 0) Hub.js("window.__hr&&__hr(" + hr + ")");
    }

    static final BluetoothGattCallback cb = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int ns) {
            if (ns == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices();
            } else if (ns == BluetoothProfile.STATE_DISCONNECTED) {
                boolean was = connected;
                connected = false;
                g.close();
                if (g == gatt) gatt = null;
                if (was) state("disconnected");
                if (want && Hub.session && dev != null) {
                    Hub.main.postDelayed(() -> {
                        if (want && gatt == null && dev != null) gatt = dev.connectGatt(Hub.app, true, cb, BluetoothDevice.TRANSPORT_LE);
                    }, 2000);
                }
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattService s = g.getService(HRS);
            if (s == null) { g.disconnect(); return; }
            BluetoothGattCharacteristic ch = s.getCharacteristic(HRM);
            if (ch == null) { g.disconnect(); return; }
            g.setCharacteristicNotification(ch, true);
            BluetoothGattDescriptor d = ch.getDescriptor(CCC);
            if (d != null) {
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                else { d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); g.writeDescriptor(d); }
            }
            connected = true;
            state("connected");
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic ch, byte[] value) {
            handle(value);
        }

        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic ch) {
            if (Build.VERSION.SDK_INT < 33) handle(ch.getValue());
        }
    };
}
