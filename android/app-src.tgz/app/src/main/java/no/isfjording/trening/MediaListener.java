package no.isfjording.trening;

import android.service.notification.NotificationListenerService;

/** Tom lytter. Den gir appen lov til å finne og styre mediesesjonen til strømmeappen. */
public class MediaListener extends NotificationListenerService { }
