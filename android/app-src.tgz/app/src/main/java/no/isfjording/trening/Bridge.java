package no.isfjording.trening;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

public class Bridge {
    static final String[] APPS = {"com.netflix.mediaclient", "no.nrk.tv", "no.tv2.sumo", "com.google.android.youtube",
        "com.disney.disneyplus", "com.wbd.stream", "com.viaplay.android"};
    final MainActivity a;

    Bridge(MainActivity a) { this.a = a; }

    @JavascriptInterface public String info() {
        try {
            JSONObject o = new JSONObject();
            o.put("v", Hub.version());
            o.put("overlay", Settings.canDrawOverlays(a));
            o.put("media", Media.hasAccess());
            JSONObject apps = new JSONObject();
            for (String p : APPS) apps.put(p, a.getPackageManager().getLaunchIntentForPackage(p) != null);
            o.put("apps", apps);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    @JavascriptInterface public void speak(String t) { Hub.speak(t); }

    @JavascriptInterface public void keepAwake(boolean on) { Hub.main.post(() -> a.keepScreen(on)); }

    @JavascriptInterface public void hrConnect() { Hub.main.post(a::connectHr); }

    @JavascriptInterface public void openApp(String pkg) { Hub.main.post(() -> Hub.pick(pkg)); }

    @JavascriptInterface public void tvDim(String pkg) { Hub.main.post(() -> Hub.tvDim(pkg)); }

    @JavascriptInterface public void tvWake() { Hub.main.post(Hub::tvWake); }

    @JavascriptInterface public void tvEnd() { Hub.main.post(Hub::tvEnd); }

    @JavascriptInterface public void overlay(String json) { Hub.main.post(() -> Hub.updateOverlay(json)); }

    @JavascriptInterface public void sessionStart() {
        Hub.main.post(() -> {
            if (Hub.session) return;
            Hub.session = true;
            a.setShowWhenLocked(true);
            a.askNotifications();
            try { a.startForegroundService(new Intent(a, SessionService.class)); } catch (Exception e) { }
            a.startTick();
        });
    }

    @JavascriptInterface public void sessionEnd() {
        Hub.main.post(() -> {
            Hub.session = false;
            a.setShowWhenLocked(false);
            Hr.stopReconnect();
            try { a.stopService(new Intent(a, SessionService.class)); } catch (Exception e) { }
        });
    }

    @JavascriptInterface public void requestOverlay() {
        Hub.main.post(() -> {
            try { a.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.getPackageName()))); }
            catch (Exception e) { a.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)); }
        });
    }

    @JavascriptInterface public void requestMedia() {
        Hub.main.post(() -> {
            try {
                Intent i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS);
                i.putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, new ComponentName(a, MediaListener.class).flattenToString());
                a.startActivity(i);
            } catch (Exception e) {
                try { a.startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); } catch (Exception e2) { }
            }
        });
    }

    @JavascriptInterface public void copy(String t) {
        Hub.main.post(() -> {
            ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Treningslogg", t));
        });
    }
}
