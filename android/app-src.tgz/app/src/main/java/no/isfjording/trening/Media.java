package no.isfjording.trening;

import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.media.AudioManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.os.SystemClock;
import android.view.KeyEvent;

import java.util.List;

/** Pause og start avspilling i strømmeappen. Bruker mediesesjonen når appen har varseltilgang, ellers medietaster. */
public class Media {
    static boolean hasAccess() {
        try {
            NotificationManager nm = (NotificationManager) Hub.app.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm.isNotificationListenerAccessGranted(new ComponentName(Hub.app, MediaListener.class));
        } catch (Exception e) { return false; }
    }

    static MediaController find() {
        if (!hasAccess()) return null;
        try {
            MediaSessionManager m = (MediaSessionManager) Hub.app.getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> list = m.getActiveSessions(new ComponentName(Hub.app, MediaListener.class));
            for (MediaController c : list) if (Hub.tvPkg.equals(c.getPackageName())) return c;
        } catch (Exception e) { }
        return null;
    }

    static void key(int code) {
        try {
            AudioManager am = (AudioManager) Hub.app.getSystemService(Context.AUDIO_SERVICE);
            long t = SystemClock.uptimeMillis();
            am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0));
            am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0));
        } catch (Exception e) { }
    }

    static void pause() {
        MediaController c = find();
        if (c != null) { try { c.getTransportControls().pause(); return; } catch (Exception e) { } }
        key(KeyEvent.KEYCODE_MEDIA_PAUSE);
    }

    static void play() {
        MediaController c = find();
        if (c != null) { try { c.getTransportControls().play(); return; } catch (Exception e) { } }
        key(KeyEvent.KEYCODE_MEDIA_PLAY);
    }
}
