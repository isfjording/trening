package no.isfjording.trening;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

/** Felles tilstand: WebView, tale, pulsfelt over strømmeappen og styring av Netflix-modus. */
public class Hub {
    static Context app;
    static Handler main = new Handler(Looper.getMainLooper());
    static SharedPreferences prefs;
    static WebView web;
    static MainActivity activity;
    static boolean session, tvActive;
    static String tvPkg = "com.netflix.mediaclient";
    static TextToSpeech tts;
    static boolean ttsReady;
    static ToneGenerator tone;

    static void init(Context c) {
        if (app != null) return;
        app = c.getApplicationContext();
        prefs = app.getSharedPreferences("trening", Context.MODE_PRIVATE);
        tts = new TextToSpeech(app, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("nb", "NO"));
                if (r < 0) r = tts.setLanguage(new Locale("no", "NO"));
                tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                tts.setSpeechRate(1.02f);
                ttsReady = true;
            }
        });
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 100); } catch (Exception e) { tone = null; }
    }

    static String version() {
        try { return app.getPackageManager().getPackageInfo(app.getPackageName(), 0).versionName; } catch (Exception e) { return "?"; }
    }

    static void js(String code) {
        main.post(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    static void speak(String t) {
        if (tts != null && ttsReady) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u" + System.currentTimeMillis());
    }

    static void beep() { try { if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 350); } catch (Exception e) { } }

    static boolean launch(String pkg) {
        try {
            Intent i = app.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            app.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    static void bringFront() {
        try {
            Intent i = new Intent(app, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            app.startActivity(i);
        } catch (Exception e) { }
    }

    /** Skjermen dempes: vis strømmeappen, start avspilling og vis pulsfeltet. */
    static void tvDim(String pkg) {
        if (pkg != null && !pkg.isEmpty()) tvPkg = pkg;
        if (!launch(tvPkg)) return;
        tvActive = true;
        showOverlay();
        main.postDelayed(() -> { if (tvActive) Media.play(); }, 1300);
        main.postDelayed(() -> { if (tvActive) Media.play(); }, 3200);
    }

    /** 10 sek før stegbytte eller trykk: pause strømmeappen og vis treningsappen. */
    static void tvWake() {
        boolean was = tvActive;
        tvActive = false;
        hideOverlay();
        Media.pause();
        if (was) { beep(); bringFront(); }
    }

    static void tvEnd() {
        boolean was = tvActive;
        tvActive = false;
        hideOverlay();
        if (was) { Media.pause(); bringFront(); }
    }

    static void tap() {
        tvActive = false;
        hideOverlay();
        Media.pause();
        bringFront();
        js("window.__tvTap&&__tvTap()");
    }

    /* ---------- Pulsfeltet ---------- */
    static View ov;
    static WindowManager.LayoutParams ovLp;
    static TextView tStep, tHr, tL, tLl, tT, tK, tNext;
    static String lastJson;

    static int dp(float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, app.getResources().getDisplayMetrics()); }

    static TextView tv(float sp, int color, boolean bold) {
        TextView t = new TextView(app);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        return t;
    }

    static LinearLayout col(TextView v, TextView l) {
        LinearLayout c = new LinearLayout(app);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(dp(6), 0, dp(6), 0);
        c.addView(v); c.addView(l);
        return c;
    }

    @SuppressLint("ClickableViewAccessibility")
    static void showOverlay() {
        if (!Settings.canDrawOverlays(app)) return;
        WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
        if (ov == null) {
            int muted = Color.parseColor("#8b97a8");
            LinearLayout root = new LinearLayout(app);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setGravity(Gravity.CENTER_HORIZONTAL);
            root.setPadding(dp(12), dp(10), dp(12), dp(10));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#D90b1016"));
            bg.setCornerRadius(dp(18));
            bg.setStroke(dp(1), Color.parseColor("#33ffffff"));
            root.setBackground(bg);
            tStep = tv(13, muted, true);
            tHr = tv(46, Color.WHITE, true);
            TextView lHr = tv(11, muted, false); lHr.setText("puls");
            tL = tv(20, Color.WHITE, true); tLl = tv(10, muted, false); tLl.setText("igjen");
            tT = tv(20, Color.WHITE, true); TextView lT = tv(10, muted, false); lT.setText("totalt");
            tK = tv(20, Color.WHITE, true); TextView lK = tv(10, muted, false); lK.setText("km");
            tNext = tv(13, Color.parseColor("#ff8a3d"), true);
            tNext.setVisibility(View.GONE);
            LinearLayout row = new LinearLayout(app);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, dp(6), 0, 0);
            row.addView(col(tL, tLl)); row.addView(col(tT, lT)); row.addView(col(tK, lK));
            root.addView(tStep); root.addView(tHr); root.addView(lHr); root.addView(row); root.addView(tNext);
            ov = root;
            ovLp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
            ovLp.gravity = Gravity.TOP | Gravity.END;
            ovLp.x = dp(8);
            ovLp.y = prefs.getInt("ovY", dp(80));
            root.setOnTouchListener(new View.OnTouchListener() {
                float downY; int startY; boolean moved;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN: downY = e.getRawY(); startY = ovLp.y; moved = false; return true;
                        case MotionEvent.ACTION_MOVE:
                            float d = e.getRawY() - downY;
                            if (Math.abs(d) > dp(8)) moved = true;
                            if (moved) { ovLp.y = Math.max(0, (int) (startY + d)); try { wm.updateViewLayout(ov, ovLp); } catch (Exception x) { } }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (moved) prefs.edit().putInt("ovY", ovLp.y).apply(); else tap();
                            return true;
                    }
                    return false;
                }
            });
            if (lastJson != null) apply(lastJson);
        }
        if (ov.getParent() == null) { try { wm.addView(ov, ovLp); } catch (Exception e) { } }
    }

    static void hideOverlay() {
        if (ov != null && ov.getParent() != null) {
            try { ((WindowManager) app.getSystemService(Context.WINDOW_SERVICE)).removeView(ov); } catch (Exception e) { }
        }
    }

    static void updateOverlay(String json) { lastJson = json; if (ov != null) apply(json); }

    static void apply(String json) {
        try {
            JSONObject o = new JSONObject(json);
            tStep.setText(o.optString("s"));
            tHr.setText(o.optString("hr", "--"));
            try { tHr.setTextColor(Color.parseColor(o.optString("hc", "#ffffff"))); } catch (Exception e) { tHr.setTextColor(Color.WHITE); }
            tL.setText(o.optString("l")); tLl.setText(o.optString("ll", "igjen"));
            tT.setText(o.optString("t"));
            String k = o.optString("k");
            tK.setText(k.isEmpty() ? "–" : k);
            String n = o.optString("n");
            tNext.setText(n);
            tNext.setVisibility(n.isEmpty() ? View.GONE : View.VISIBLE);
        } catch (Exception e) { }
    }
}
