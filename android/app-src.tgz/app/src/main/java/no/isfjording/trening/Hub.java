package no.isfjording.trening;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

/** Felles tilstand: WebView, tale, pulsstripe over strømmeappen og styring av Netflix-modus. */
public class Hub {
    static Context app;
    static Handler main = new Handler(Looper.getMainLooper());
    static SharedPreferences prefs;
    static WebView web;
    static MainActivity activity;
    static boolean session, tvActive, picking;
    static String tvPkg = "com.netflix.mediaclient";
    static TextToSpeech tts;
    static boolean ttsReady;
    static ToneGenerator tone;

    static void init(Context c) {
        if (app != null) return;
        app = c.getApplicationContext();
        prefs = app.getSharedPreferences("trening", Context.MODE_PRIVATE);
        tts = new TextToSpeech(app, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("nb", "NO"));
                if (r < 0) tts.setLanguage(new Locale("no", "NO"));
                tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                tts.setSpeechRate(1.02f);
                ttsReady = true;
            }
        });
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 100); } catch (Exception e) { tone = null; }
    }

    static String version() {
        try { return app.getPackageManager().getPackageInfo(app.getPackageName(), 0).versionName; } catch (Exception e) { return "?"; }
    }

    static void js(String code) { main.post(() -> { if (web != null) web.evaluateJavascript(code, null); }); }

    static void speak(String t) { if (tts != null && ttsReady) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u" + System.currentTimeMillis()); }

    static void beep() { try { if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 350); } catch (Exception e) { } }

    static boolean launch(String pkg) {
        try {
            Intent i = app.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            app.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    @SuppressWarnings("deprecation")
    static void wakeScreen() {
        try {
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            PowerManager.WakeLock w = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "trening:wake");
            w.acquire(4000);
        } catch (Exception e) { }
    }

    static void bringFront() {
        wakeScreen();
        try {
            Intent i = new Intent(app, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            app.startActivity(i);
        } catch (Exception e) { }
    }

    /** Pause strømmeappen først (så den ikke går til bilde-i-bilde), hent så treningsappen fram. */
    static void pauseAndFront(Runnable after) {
        Media.pause();
        main.postDelayed(() -> {
            bringFront();
            main.postDelayed(() -> { if (!tvActive) hideOverlay(); hidePick(); if (after != null) after.run(); }, 1500);
        }, 350);
    }

    /* ---------- Velg hva du vil se ---------- */
    static int playingFor, pickTicks;
    static final Runnable pickPoll = new Runnable() {
        @Override public void run() {
            if (!picking) return;
            pickTicks++;
            if (Media.isPlaying()) playingFor++; else playingFor = 0;
            int need = Media.hasAccess() ? 2 : 3;
            if (playingFor >= need) { picking = false; pauseAndFront(null); return; }
            if (pickTicks > 900) { picking = false; hidePick(); return; }
            main.postDelayed(this, 1000);
        }
    };

    static void pick(String pkg) {
        if (pkg != null && !pkg.isEmpty()) tvPkg = pkg;
        if (!launch(tvPkg)) return;
        picking = true; playingFor = 0; pickTicks = 0;
        showPick();
        main.removeCallbacks(pickPoll);
        main.postDelayed(pickPoll, 2500);
    }

    static void pickDone() { picking = false; main.removeCallbacks(pickPoll); pauseAndFront(null); }

    /* ---------- Netflix-modus under økta ---------- */
    static void tvDim(String pkg) {
        if (pkg != null && !pkg.isEmpty()) tvPkg = pkg;
        if (!launch(tvPkg)) return;
        tvActive = true;
        showOverlay();
        main.postDelayed(() -> { if (tvActive) Media.play(); }, 1300);
        main.postDelayed(() -> { if (tvActive) Media.play(); }, 3200);
    }

    static void tvWake() {
        boolean was = tvActive;
        tvActive = false;
        if (was) { beep(); pauseAndFront(null); } else hideOverlay();
    }

    static void tvEnd() {
        boolean was = tvActive;
        tvActive = false;
        if (was) pauseAndFront(null); else hideOverlay();
    }

    static void tap() {
        tvActive = false;
        pauseAndFront(() -> js("window.__tvTap&&__tvTap()"));
    }

    /** Appen lukkes (sveipet bort): stopp økta, Netflix-modus og bakgrunnstjenesten helt. */
    static void endAll() {
        session = false; tvActive = false; picking = false;
        main.removeCallbacks(pickPoll);
        hideOverlay(); hidePick();
        Hr.stopReconnect();
        try { app.stopService(new Intent(app, SessionService.class)); } catch (Exception e) { }
    }

    /* ---------- Pulsstripen ---------- */
    static View ov;
    static WindowManager.LayoutParams ovLp;
    static TextView tStep, tHr, tL, tLl, tT, tK, tNext;
    static String lastJson;

    static int dp(float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, app.getResources().getDisplayMetrics()); }

    static WindowManager wm() { return (WindowManager) app.getSystemService(Context.WINDOW_SERVICE); }

    static TextView tv(int maxSp, int color, boolean bold, int lines) {
        TextView t = new TextView(app);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setMaxLines(lines);
        if (bold) t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        t.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        if (lines == 1) t.setAutoSizeTextTypeUniformWithConfiguration(9, maxSp, 1, TypedValue.COMPLEX_UNIT_SP);
        else t.setTextSize(TypedValue.COMPLEX_UNIT_SP, maxSp);
        return t;
    }

    static View gap(int h) { View v = new View(app); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h))); return v; }

    static int stripWidth() {
        int w = wm().getCurrentWindowMetrics().getBounds().width();
        return Math.max((int) (w * 0.10f), dp(78));
    }

    static void showOverlay() {
        if (!Settings.canDrawOverlays(app)) return;
        if (ov == null) {
            int muted = Color.parseColor("#8b97a8");
            LinearLayout root = new LinearLayout(app);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setGravity(Gravity.CENTER);
            root.setPadding(dp(6), dp(12), dp(6), dp(12));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#E60b1016"));
            root.setBackground(bg);
            tStep = tv(13, muted, true, 3);
            tHr = tv(40, Color.WHITE, true, 1);
            TextView lHr = tv(10, muted, false, 1); lHr.setText("puls");
            tL = tv(20, Color.WHITE, true, 1); tLl = tv(10, muted, false, 1); tLl.setText("igjen");
            tT = tv(20, Color.WHITE, true, 1); TextView lT = tv(10, muted, false, 1); lT.setText("totalt");
            tK = tv(20, Color.WHITE, true, 1); TextView lK = tv(10, muted, false, 1); lK.setText("km");
            tNext = tv(12, Color.parseColor("#ff8a3d"), true, 4);
            tNext.setVisibility(View.GONE);
            root.addView(tStep); root.addView(gap(14));
            root.addView(tHr); root.addView(lHr); root.addView(gap(18));
            root.addView(tL); root.addView(tLl); root.addView(gap(12));
            root.addView(tT); root.addView(lT); root.addView(gap(12));
            root.addView(tK); root.addView(lK); root.addView(gap(14));
            root.addView(tNext);
            root.setOnClickListener(v -> tap());
            ov = root;
            ovLp = new WindowManager.LayoutParams(stripWidth(), WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT);
            ovLp.gravity = Gravity.END | Gravity.TOP;
            ovLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            if (lastJson != null) apply(lastJson);
        }
        ovLp.width = stripWidth();
        try {
            if (ov.getParent() == null) wm().addView(ov, ovLp); else wm().updateViewLayout(ov, ovLp);
        } catch (Exception e) { }
    }

    static void hideOverlay() {
        if (ov != null && ov.getParent() != null) { try { wm().removeView(ov); } catch (Exception e) { } }
    }

    static void updateOverlay(String json) { lastJson = json; if (ov != null) apply(json); }

    static void apply(String json) {
        try {
            JSONObject o = new JSONObject(json);
            tStep.setText(o.optString("s"));
            tHr.setText(o.optString("hr", "--"));
            try { tHr.setTextColor(Color.parseColor(o.optString("hc", "#ffffff"))); } catch (Exception e) { tHr.setTextColor(Color.WHITE); }
            tL.setText(o.optString("l")); tLl.setText(o.optString("ll", "igjen"));
            tT.setText(o.optString("t"));
            String k = o.optString("k");
            tK.setText(k.isEmpty() ? "–" : k);
            String n = o.optString("n");
            tNext.setText(n);
            tNext.setVisibility(n.isEmpty() ? View.GONE : View.VISIBLE);
            if (ov != null && ov.getParent() != null) {
                int w = stripWidth();
                if (w != ovLp.width) { ovLp.width = w; try { wm().updateViewLayout(ov, ovLp); } catch (Exception e) { } }
            }
        } catch (Exception e) { }
    }

    /* ---------- Knapp «Tilbake til økta» mens du velger ---------- */
    static View pv;

    @SuppressLint("SetTextI18n")
    static void showPick() {
        if (!Settings.canDrawOverlays(app)) return;
        if (pv == null) {
            TextView b = new TextView(app);
            b.setText("✓ Tilbake til økta");
            b.setTextColor(Color.parseColor("#0b1016"));
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            b.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            b.setPadding(dp(16), dp(10), dp(16), dp(10));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#ff8a3d"));
            bg.setCornerRadius(dp(22));
            b.setBackground(bg);
            b.setOnClickListener(v -> pickDone());
            pv = b;
        }
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(28);
        try { if (pv.getParent() == null) wm().addView(pv, lp); } catch (Exception e) { }
    }

    static void hidePick() {
        if (pv != null && pv.getParent() != null) { try { wm().removeView(pv); } catch (Exception e) { } }
    }
}
