package no.isfjording.trening;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    static final String URL = "https://isfjording.github.io/trening/";
    static final String HOST = "isfjording.github.io";
    WebView web;
    boolean resumed;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (Hub.session) {
                if (!resumed && web != null) web.evaluateJavascript("window.__nt&&__nt()", null);
                Hub.main.postDelayed(this, 500);
            }
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Hub.init(this);
        Hub.activity = this;
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0b1016"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setUserAgentString(s.getUserAgentString() + " TreningApp/" + Hub.version());
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/trening") && !u.getPath().endsWith(".apk")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception e) { }
                return true;
            }
        });
        Hub.web = web;
        setContentView(web);
        if (b != null) web.restoreState(b);
        if (b == null || web.getUrl() == null) web.loadUrl(URL);
        immersive();
    }

    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (web != null) web.saveState(out); }

    void immersive() {
        getWindow().setDecorFitsSystemWindows(false);
        WindowInsetsController c = getWindow().getInsetsController();
        if (c != null) {
            c.hide(WindowInsets.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        Hub.activity = this;
        if (Hub.picking) { Hub.picking = false; Hub.main.removeCallbacks(Hub.pickPoll); Hub.hidePick(); }
        if (Hub.tvActive) { Hub.tvActive = false; Media.pause(); Hub.js("window.__tvTap&&__tvTap()"); Hub.main.postDelayed(Hub::hideOverlay, 800); }
        Hub.js("window.__resume&&__resume()");
    }

    @Override protected void onPause() { super.onPause(); resumed = false; }

    void startTick() { Hub.main.removeCallbacks(tick); Hub.main.post(tick); }

    void keepScreen(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.__back?__back():''", r -> {
            if (r == null || !r.contains("1")) moveTaskToBack(true);
        });
    }

    boolean hasBtPerms() {
        return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    void connectHr() {
        if (hasBtPerms()) Hr.connect(this);
        else requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, 7);
    }

    void askNotifications() {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            && !Hub.prefs.getBoolean("askedNotif", false)) {
            Hub.prefs.edit().putBoolean("askedNotif", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 8);
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] g) {
        super.onRequestPermissionsResult(code, p, g);
        if (code == 7) {
            if (hasBtPerms()) Hr.connect(this); else Hub.js("window.__hrState&&__hrState('noperm')");
        }
    }

    @Override protected void onDestroy() {
        if (Hub.activity == this) Hub.activity = null;
        super.onDestroy();
    }
}
